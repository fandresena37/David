a=document.querySelector("input");
a.addEventListener("click", function () {
    fetch("/json/liste.json")
      .then((response) => response.json())
      .then((data) => {
      const gridContainer = document.getElementById("grid-container");
      data.forEach((product) => {
        createProduct(product, gridContainer);
      });
    })
    .catch((error) => console.error(error));
});

//Création de la conteneur de produit

function createProduct(product, gridContainer) {
  const grid = document.createElement("div");
  grid.classList.add("grid");

  const imgCont = document.createElement("div");
  imgCont.classList.add("img");

  const img = document.createElement("img");
  img.src = product.url;
  img.alt = product.nom;

  imgCont.appendChild(img);

  const title = document.createElement("h2");
  title.innerText = product.nom;

  const price = document.createElement("span");
  price.innerText = ("" + product.prix.toFixed(2) + " €").replace(".", ",");

  const btnCont = document.createElement("div");
  btnCont.classList.add("btn-cont");

  const button = document.createElement("button");
  button.classList.add("add");
  button.innerText = "Ajouter au panier";

  button.addEventListener("click", () => {
    product.nb = 1;
    product.total = product.nb * product.prix;
    basket.push(product);
    addBasket(product, button, btnCont);
    actionOpenBasket();
  });
  btnCont.appendChild(button);

  grid.appendChild(imgCont);
  grid.append(title);
  grid.appendChild(price);
  grid.appendChild(btnCont);

  gridContainer.appendChild(grid);
}