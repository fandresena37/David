button=document.querySelector("button");
button.addEventListener('click', function() {
    // Sélectionner les éléments nécessaires du DOM
        const titre=document.getElementById("titre").value();
        const auteur=document.getElementById("auteur").value();
        const isbn=document.getElementById("isbn").value();
        const editeur=document.getElementById("editeur").value();
        const date=document.getElementById("date").value();
        const genre=document.getElementById("genre").value();
        constresume=document.getElementById("resume").value();
        const langue=document.getElementById("langue").value();
        const page=document.getElementById("page").value();
        const disp=document.getElementById("disp").value();
        const etat=document.getElementById("etat").value();
        const ampl=document.getElementById("ampl").value();
    
    // Charger les données JSON depuis le fichier books.json
    async function fetchBooksData() {
        try {
            const response = await fetch('books.json'); // Charger le fichier JSON
            const data = await response.json(); // Convertir la réponse en JSON
            
            // Écouter les clics sur les boutons pour afficher les détails des livres
            document.getElementById('loadBook1').addEventListener('click', function() {
                displayBookDetails(data[0]); // Afficher les détails du Livre 1
            });

            button.addEventListener('click', function() {
                displayBookDetails(data[1]); // Afficher les détails du Livre 2
            });
        } catch (error) {
            console.error('Erreur lors du chargement des données :', error);
        }
    }

    // Afficher les détails d'un livre spécifique
    function displayBookDetails(book) {
        bookTitleElem.textContent = book.title;
        bookAuthorElem.textContent = book.author;
        bookDescriptionElem.textContent = book.description;
    }

    // Charger les détails des livres au chargement de la page
    fetchBooksData();
});
