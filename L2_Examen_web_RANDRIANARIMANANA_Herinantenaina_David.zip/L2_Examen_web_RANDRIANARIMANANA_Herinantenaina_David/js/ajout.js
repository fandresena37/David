a=getElementById("valider");
a.addEventListener('click',ajouter());
function ajouter(){
    // Exemple de données JSON à ajouter
    const newData = {
        titre:document.getElementById("titre").value(),
        auteur:document.getElementById("auteur").value(),
        isbn:document.getElementById("isbn").value(),
        editeur:document.getElementById("editeur").value(),
        date:document.getElementById("date").value(),
        genre:document.getElementById("genre").value(),
        resume:document.getElementById("resume").value(),
        langue:document.getElementById("langue").value(),
        page:document.getElementById("page").value(),
        disp:document.getElementById("disp").value(),
        etat:document.getElementById("etat").value(),
        ampl:document.getElementById("ampl").value()
    };

    // Récupérer les données existantes de localStorage (s'il y en a)
    let existingData = JSON.parse(localStorage.getItem('myData')) || [];

    // Ajouter de nouvelles données à celles existantes
    existingData.push(newData);

    // Stocker les données mises à jour dans localStorage
    localStorage.setItem('myData', JSON.stringify(existingData));

    console.log('Données ajoutées à localStorage avec succès.');


    // Récupérer les données depuis localStorage
    let storedData = JSON.parse(localStorage.getItem('myData'));

    if (storedData) {
        console.log('Données récupérées depuis localStorage :', storedData);

        // Faire quelque chose avec les données récupérées
        storedData.forEach(item => {
            console.log(`Nom: ${item.name}, Âge: ${item.age}, Email: ${item.email}`);
        });
    } else {
        console.log('Aucune donnée trouvée dans localStorage.');
    }
}