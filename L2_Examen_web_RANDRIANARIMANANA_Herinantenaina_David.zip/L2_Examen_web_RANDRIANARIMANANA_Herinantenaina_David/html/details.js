<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Afficher les détails d'un livre</title>
</head>
<body>
    <div id="bookDetails">
        <h2 id="bookTitle"></h2>
        <p><strong>Auteur: </strong><span id="bookAuthor"></span></p>
        <p id="bookDescription"></p>
    </div>
    <button id="loadBook1">Afficher les détails du Livre 1</button>
    <button id="loadBook2">Afficher les détails du Livre 2</button>

    <script src="script.js"></script> <!-- Script JavaScript pour manipuler les données -->
</body>
</html>
